# Replit.md

## Overview

This is a full-stack React web application featuring a sugar cane farming game. The project uses a modern TypeScript stack with Express.js backend, React frontend, PostgreSQL database with Drizzle ORM, and includes comprehensive UI components built with Radix UI and Tailwind CSS.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (January 2025)

✓ Adjusted crop pricing - reduced harvest values to balance economy
✓ Added irrigation system with water requirements for each crop type
✓ Water can be purchased in the shop at $2 per unit
✓ Each sugar cane type requires different amounts of water (1-6 units)
✓ Added auto-irrigation upgrade system with water cost reduction
✓ Added water tank upgrades for additional water efficiency
✓ Updated shop interface with resource and seed sections
✓ Water consumption is calculated based on upgrades and crop requirements
✓ Implemented progressive XP system - each level requires more XP (Level 1: 100, Level 2: 150, etc.)
✓ Fixed planting bug when player has insufficient money or water
✓ Added visual feedback for resource requirements in seed selector
✓ XP display now shows current level progress instead of total XP

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with hot module replacement
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Comprehensive Radix UI component library with custom wrappers
- **State Management**: Zustand for global state (game state, audio controls)
- **3D Graphics**: React Three Fiber ecosystem (@react-three/fiber, @react-three/drei, @react-three/postprocessing)
- **Data Fetching**: TanStack Query for server state management

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Style**: RESTful endpoints with `/api` prefix
- **Middleware**: JSON parsing, URL encoding, request logging
- **Development**: Hot reload with Vite integration in development mode

### Data Storage Solutions
- **Database**: PostgreSQL via Neon Database serverless
- **ORM**: Drizzle ORM for type-safe database operations
- **Connection**: @neondatabase/serverless for edge-compatible connections
- **Migrations**: Drizzle Kit for schema management
- **Development Storage**: In-memory storage implementation for local development

### Authentication and Authorization
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **User Model**: Basic username/password schema with Zod validation
- **Storage Interface**: Abstracted storage layer supporting both memory and database implementations

## Key Components

### Game Engine
- **Farm Grid System**: 2D grid-based farming simulation
- **Crop Growth**: Time-based growth mechanics with multiple stages
- **Resource Management**: Money, experience, and level progression
- **Shop System**: Seed purchasing and inventory management
- **Upgrade System**: Player progression enhancements
- **Save/Load**: Local storage persistence for game state

### Audio System
- **Background Music**: Ambient audio support
- **Sound Effects**: Hit and success sound triggers
- **Mute Controls**: Toggle audio on/off functionality
- **Performance**: Optimized audio cloning for overlapping effects

### UI System
- **Design System**: Comprehensive component library with consistent theming
- **Responsive Design**: Mobile-first approach with breakpoint handling
- **Accessibility**: ARIA compliance through Radix UI primitives
- **Animations**: CSS transitions and keyframe animations
- **Touch Support**: Mobile-optimized interactions

## Data Flow

### Client-Side State Management
1. **Game State**: Zustand stores manage farm grid, player stats, and game progression
2. **Audio State**: Separate store for audio controls and sound management
3. **Local Storage**: Game state persistence for offline play
4. **Component State**: React state for UI interactions and form handling

### Server-Client Communication
1. **API Routes**: RESTful endpoints for user management and game data
2. **Request/Response**: JSON-based communication with error handling
3. **Session Management**: PostgreSQL-backed sessions for user authentication
4. **Development Logging**: Comprehensive request logging with response capture

### Database Operations
1. **User Management**: CRUD operations for user accounts
2. **Schema Management**: Drizzle migrations for database evolution
3. **Type Safety**: End-to-end TypeScript types from database to frontend
4. **Connection Pooling**: Serverless-optimized database connections

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, TypeScript
- **Build Tools**: Vite, ESBuild for production builds
- **Development**: TSX for development server, TypeScript compiler

### UI and Styling
- **Radix UI**: Complete primitive component library
- **Tailwind CSS**: Utility-first CSS framework with PostCSS
- **Fonts**: Inter font family via Fontsource
- **Icons**: Lucide React icon library

### Backend Infrastructure
- **Express.js**: Web framework with middleware support
- **Database**: Drizzle ORM, Neon Database, PostgreSQL driver
- **Session**: Connect-pg-simple for session storage
- **Validation**: Zod for runtime type validation

### Game and Audio
- **3D Graphics**: React Three Fiber ecosystem for WebGL rendering
- **Audio**: Web Audio API integration
- **State**: Zustand for reactive state management
- **Utilities**: Date-fns for time manipulation, Nanoid for ID generation

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite bundles React app to `dist/public`
2. **Backend Build**: ESBuild compiles server to `dist/index.js`
3. **Asset Handling**: Support for GLTF, GLB, audio files
4. **Production Optimization**: Tree shaking, minification, code splitting

### Environment Configuration
1. **Database**: `DATABASE_URL` environment variable for PostgreSQL connection
2. **Node Environment**: `NODE_ENV=production` for production builds
3. **TypeScript**: Incremental compilation with build info caching

### Development Workflow
1. **Hot Reload**: Vite HMR for instant feedback
2. **Type Checking**: Real-time TypeScript validation
3. **Database**: `npm run db:push` for schema synchronization
4. **Error Handling**: Runtime error overlay for debugging

### Production Considerations
1. **Static Assets**: Efficient serving of built frontend assets
2. **API Routing**: Express serves both API and static content
3. **Error Handling**: Comprehensive error middleware with status codes
4. **Performance**: Optimized bundles with modern JavaScript features