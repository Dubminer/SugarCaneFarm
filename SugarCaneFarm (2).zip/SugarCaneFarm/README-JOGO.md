# 🌱 Jogo de Fazenda de Cana-de-Açúcar

Um jogo de simulação de fazenda 2D focado no cultivo de cana-de-açúcar, desenvolvido em React/TypeScript.

## 🎮 Como Jogar

### Objetivo
Torne-se um fazendeiro especializado em cana-de-açúcar! Plante diferentes variedades, gerencie seus recursos e faça upgrades para se tornar o melhor produtor.

### Mecânicas Principais

**🌾 Plantio e Colheita**
- Clique em uma célula vazia para plantar a semente selecionada
- Espere a cana crescer (barras de progresso mostram o crescimento)
- Clique na cana madura para colher e ganhar dinheiro + XP

**💰 Sistema de Recursos**
- **Dinheiro**: Usado para comprar sementes e upgrades
- **Água**: Necessária para irrigar as plantas (cada tipo precisa de quantidades diferentes)
- **XP**: Ganho ao colher plantas, aumenta seu nível

**🛒 Loja**
- **Seção Sementes**: Compre diferentes tipos de cana-de-açúcar
- **Seção Recursos**: Compre água ($2 por unidade)
- **Seção Upgrades**: Melhore sua eficiência de cultivo

**⬆️ Sistema de Upgrades**
- **Auto-Irrigação**: Reduz custos de água em 50%
- **Tanque de Água**: Cada nível reduz custos de água em 25%
- **Ferramentas**: Aumenta valor de colheita
- **Fertilizante**: Aumenta XP ganho

### Tipos de Cana-de-Açúcar

1. **Cana Comum** - $10, 1 água, 30s crescimento
2. **Cana Doce** - $25, 2 água, 45s crescimento  
3. **Cana Premium** - $50, 3 água, 60s crescimento
4. **Cana Orgânica** - $100, 4 água, 90s crescimento
5. **Cana Especial** - $200, 5 água, 120s crescimento
6. **Cana Rara** - $500, 6 água, 180s crescimento

### Sistema de Experiência
- **XP Progressivo**: Cada nível requer mais XP que o anterior
  - Nível 1: 100 XP
  - Nível 2: 150 XP  
  - Nível 3: 200 XP (e assim por diante...)
- A barra de XP mostra o progresso atual do nível

## 🚀 Como Executar

### Pré-requisitos
- Node.js (versão 18 ou superior)
- NPM ou Yarn

### Instalação
1. Extraia o arquivo do jogo
2. Abra o terminal na pasta do projeto
3. Execute: `npm install`
4. Execute: `npm run dev`
5. Abra http://localhost:5000 no navegador

### Scripts Disponíveis
- `npm run dev` - Inicia o servidor de desenvolvimento
- `npm run build` - Constrói a versão de produção
- `npm run db:push` - Sincroniza o banco de dados (se usar PostgreSQL)

## 🔧 Arquitetura Técnica

### Frontend
- **React 18** com TypeScript
- **Vite** para build e desenvolvimento
- **Tailwind CSS** para estilização
- **Zustand** para gerenciamento de estado
- **Radix UI** para componentes da interface

### Backend
- **Express.js** com TypeScript
- **PostgreSQL** com Drizzle ORM (opcional)
- **Armazenamento local** para desenvolvimento

### Funcionalidades
- Sistema de fazenda em grid 2D
- Crescimento de culturas baseado em tempo
- Sistema de loja e upgrades
- Irrigação com consumo de água
- Progressão de níveis e XP
- Salvamento automático no localStorage

## 🎯 Dicas de Jogo

1. **Comece pequeno**: Plante cana comum primeiro para acumular dinheiro
2. **Gerencie a água**: Compre água suficiente antes de plantar
3. **Invista em upgrades**: Auto-irrigação economiza muito dinheiro a longo prazo
4. **Diversifique**: Plante diferentes tipos para maximizar lucros
5. **Observe o tempo**: Plantas mais caras demoram mais para crescer

## 📝 Informações de Desenvolvimento

- **Linguagem**: Português Brasileiro
- **Plataforma**: Web (HTML5)
- **Responsivo**: Funciona em desktop e mobile
- **Salvamento**: Automático no navegador

---

**Versão**: 1.0  
**Desenvolvido**: Janeiro 2025  
**Compatibilidade**: Navegadores modernos

Divirta-se cultivando cana-de-açúcar! 🌱🚜