import { useFarmGame } from "../lib/stores/useFarmGame";
import { sugarCaneTypes, shopItems } from "../lib/gameData";

export default function Shop() {
  const { money, level, water, toggleShop, buySeeds, buyWater } = useFarmGame();

  const handleBuySeeds = (seedType: any, quantity: number) => {
    const totalCost = seedType.cost * quantity;
    if (money >= totalCost) {
      buySeeds(seedType, quantity);
    }
  };

  return (
    <div className="shop-overlay">
      <div className="shop-modal">
        <div className="shop-header">
          <h2>🏪 Sugar Cane Shop</h2>
          <button className="close-btn" onClick={toggleShop}>✕</button>
        </div>
        
        <div className="shop-content">
          <div className="shop-info">
            <p>💰 Your Money: ${money}</p>
            <p>⭐ Your Level: {level}</p>
            <p>💧 Your Water: {water}</p>
          </div>

          <div className="shop-items">
            {/* Water Section */}
            <div className="shop-section">
              <h3 className="section-title">💧 Resources</h3>
              <div className="shop-item">
                <div className="item-icon">💧</div>
                <div className="item-details">
                  <h3>Water</h3>
                  <p className="item-description">Essential for crop irrigation. Each crop type requires different amounts of water.</p>
                  <div className="item-stats">
                    <span>💧 Current: {water}</span>
                    <span>💰 Cost: $2 per unit</span>
                  </div>
                </div>
                <div className="item-actions">
                  <div className="item-price">$2</div>
                  <div className="quantity-controls">
                    <button 
                      onClick={() => buyWater(1)}
                      disabled={money < 2}
                      className="buy-btn"
                    >
                      Buy 1
                    </button>
                    <button 
                      onClick={() => buyWater(10)}
                      disabled={money < 20}
                      className="buy-btn"
                    >
                      Buy 10
                    </button>
                    <button 
                      onClick={() => buyWater(50)}
                      disabled={money < 100}
                      className="buy-btn"
                    >
                      Buy 50
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Seeds Section */}
            <div className="shop-section">
              <h3 className="section-title">🌱 Seeds</h3>
              {sugarCaneTypes.map((seedType) => {
                const isUnlocked = level >= seedType.levelRequired;
                
                return (
                  <div 
                    key={seedType.id} 
                    className={`shop-item ${!isUnlocked ? 'locked' : ''}`}
                  >
                    <div className="item-icon">🌱</div>
                    <div className="item-details">
                      <h3>{seedType.name}</h3>
                      <p className="item-description">{seedType.description}</p>
                      <div className="item-stats">
                        <span>💰 Value: ${seedType.baseValue}</span>
                        <span>⏱️ Growth: {seedType.growthTime / 1000 / 60}min</span>
                        <span>📈 XP: {seedType.experience}</span>
                        <span>💧 Water: {seedType.waterRequired} per plant</span>
                      </div>
                      {!isUnlocked && (
                        <p className="unlock-requirement">
                          🔒 Requires Level {seedType.levelRequired}
                        </p>
                      )}
                    </div>
                    <div className="item-actions">
                      <div className="item-price">${seedType.cost}</div>
                      {isUnlocked && (
                        <div className="quantity-controls">
                          <button 
                            onClick={() => handleBuySeeds(seedType, 1)}
                            disabled={money < seedType.cost}
                            className="buy-btn"
                          >
                            Buy 1
                          </button>
                          <button 
                            onClick={() => handleBuySeeds(seedType, 5)}
                            disabled={money < seedType.cost * 5}
                            className="buy-btn"
                          >
                            Buy 5
                          </button>
                          <button 
                            onClick={() => handleBuySeeds(seedType, 10)}
                            disabled={money < seedType.cost * 10}
                            className="buy-btn"
                          >
                            Buy 10
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
