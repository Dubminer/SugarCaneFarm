import { useFarmGame } from "../lib/stores/useFarmGame";
import { sugarCaneTypes } from "../lib/gameData";

export default function GameUI() {
  const { 
    money, 
    experience, 
    level, 
    water,
    selectedSeed, 
    setSelectedSeed,
    toggleShop,
    toggleUpgrades,
    saveGame,
    resetGame
  } = useFarmGame();

  // Calculate XP progress for current level
  const getXpRequiredForLevel = (level: number): number => {
    return 100 + (level - 1) * 50;
  };
  
  const getTotalXpForLevel = (targetLevel: number): number => {
    let totalXp = 0;
    for (let i = 1; i < targetLevel; i++) {
      totalXp += getXpRequiredForLevel(i);
    }
    return totalXp;
  };

  const currentLevelStartXp = getTotalXpForLevel(level);
  const nextLevelStartXp = getTotalXpForLevel(level + 1);
  const currentLevelProgress = experience - currentLevelStartXp;
  const xpRequiredForCurrentLevel = nextLevelStartXp - currentLevelStartXp;
  const experienceProgress = (currentLevelProgress / xpRequiredForCurrentLevel) * 100;

  return (
    <div className="game-ui">
      <div className="player-stats">
        <div className="stat-item">
          <span className="stat-label">💰 Money:</span>
          <span className="stat-value">${money}</span>
        </div>
        <div className="stat-item">
          <span className="stat-label">⭐ Level:</span>
          <span className="stat-value">{level}</span>
        </div>
        <div className="stat-item">
          <span className="stat-label">📈 XP:</span>
          <span className="stat-value">{currentLevelProgress}/{xpRequiredForCurrentLevel}</span>
          <div className="xp-bar">
            <div 
              className="xp-progress"
              style={{ width: `${Math.max(0, Math.min(100, experienceProgress))}%` }}
            />
          </div>
        </div>
        <div className="stat-item">
          <span className="stat-label">💧 Water:</span>
          <span className="stat-value">{water}</span>
        </div>
      </div>

      <div className="seed-selector">
        <h3>Select Seed:</h3>
        <div className="seed-options">
          {sugarCaneTypes.map((seedType) => {
            const canAfford = money >= seedType.cost;
            const hasEnoughWater = water >= seedType.waterRequired;
            const isAvailable = canAfford && hasEnoughWater;
            
            return (
              <button
                key={seedType.id}
                className={`seed-option ${selectedSeed?.id === seedType.id ? 'selected' : ''} ${!isAvailable ? 'unavailable' : ''}`}
                onClick={() => setSelectedSeed(seedType)}
                disabled={!canAfford}
                title={!canAfford ? `Need $${seedType.cost}` : !hasEnoughWater ? `Need ${seedType.waterRequired} water` : ''}
              >
                <div className="seed-icon">🌱</div>
                <div className="seed-info">
                  <div className="seed-name">{seedType.name}</div>
                  <div className="seed-cost">${seedType.cost} • {seedType.waterRequired}💧</div>
                </div>
              </button>
            );
          })}
        </div>
        
        {selectedSeed && (
          <div className="resource-status">
            {money < selectedSeed.cost && (
              <div className="resource-warning">⚠️ Not enough money (need ${selectedSeed.cost})</div>
            )}
            {water < selectedSeed.waterRequired && (
              <div className="resource-warning">⚠️ Not enough water (need {selectedSeed.waterRequired})</div>
            )}
          </div>
        )}
      </div>

      <div className="game-controls">
        <button className="control-btn" onClick={toggleShop}>
          🏪 Shop
        </button>
        <button className="control-btn" onClick={toggleUpgrades}>
          ⚡ Upgrades
        </button>
        <button className="control-btn" onClick={saveGame}>
          💾 Save
        </button>
        <button className="control-btn danger" onClick={resetGame}>
          🔄 Reset
        </button>
      </div>
    </div>
  );
}
