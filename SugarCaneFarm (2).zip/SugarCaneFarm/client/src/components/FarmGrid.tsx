import { useFarmGame } from "../lib/stores/useFarmGame";
import CropTile from "./CropTile";

export default function FarmGrid() {
  const { farmGrid, plantCrop, harvestCrop, selectedSeed, money, water, playerUpgrades } = useFarmGame();

  const handleTileClick = (row: number, col: number) => {
    const tile = farmGrid[row][col];
    
    if (tile.crop) {
      // If there's a crop and it's ready, harvest it
      if (tile.crop.growthStage >= tile.crop.maxGrowthStage) {
        harvestCrop(row, col);
      }
    } else {
      // If no crop and we have a selected seed, check if we can plant it
      if (selectedSeed) {
        const hasAutoIrrigation = playerUpgrades.autoIrrigation > 0;
        const waterTankLevel = playerUpgrades.waterTank || 0;
        const waterCostReduction = waterTankLevel * 0.25 + (hasAutoIrrigation ? 0.5 : 0);
        const waterCost = Math.max(1, Math.ceil(selectedSeed.waterRequired * (1 - waterCostReduction)));
        
        // Check both money and water requirements
        if (money >= selectedSeed.cost && (hasAutoIrrigation || water >= waterCost)) {
          plantCrop(row, col, selectedSeed);
        }
      }
    }
  };

  return (
    <div className="farm-grid">
      <h2 className="farm-title">Sugar Cane Farm</h2>
      <div className="grid-container">
        {farmGrid.map((row, rowIndex) =>
          row.map((tile, colIndex) => (
            <CropTile
              key={`${rowIndex}-${colIndex}`}
              tile={tile}
              onClick={() => handleTileClick(rowIndex, colIndex)}
              canPlant={!tile.crop && !!selectedSeed && money >= (selectedSeed?.cost || 0) && (() => {
                if (!selectedSeed) return false;
                const hasAutoIrrigation = playerUpgrades.autoIrrigation > 0;
                const waterTankLevel = playerUpgrades.waterTank || 0;
                const waterCostReduction = waterTankLevel * 0.25 + (hasAutoIrrigation ? 0.5 : 0);
                const waterCost = Math.max(1, Math.ceil(selectedSeed.waterRequired * (1 - waterCostReduction)));
                return hasAutoIrrigation || water >= waterCost;
              })()}
              canHarvest={!!tile.crop && tile.crop.growthStage >= tile.crop.maxGrowthStage}
            />
          ))
        )}
      </div>
    </div>
  );
}
