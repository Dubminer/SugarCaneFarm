import { useFarmGame } from "../lib/stores/useFarmGame";
import { upgrades } from "../lib/gameData";

export default function Upgrades() {
  const { money, level, playerUpgrades, toggleUpgrades, buyUpgrade } = useFarmGame();

  const handleBuyUpgrade = (upgrade: any) => {
    if (money >= upgrade.cost && level >= upgrade.levelRequired) {
      buyUpgrade(upgrade);
    }
  };

  return (
    <div className="upgrades-overlay">
      <div className="upgrades-modal">
        <div className="upgrades-header">
          <h2>⚡ Farm Upgrades</h2>
          <button className="close-btn" onClick={toggleUpgrades}>✕</button>
        </div>
        
        <div className="upgrades-content">
          <div className="upgrades-info">
            <p>💰 Your Money: ${money}</p>
            <p>⭐ Your Level: {level}</p>
          </div>

          <div className="upgrades-list">
            {upgrades.map((upgrade) => {
              const isUnlocked = level >= upgrade.levelRequired;
              const isOwned = playerUpgrades[upgrade.id] > 0;
              const currentLevel = playerUpgrades[upgrade.id] || 0;
              const maxLevel = upgrade.maxLevel || 1;
              const isMaxLevel = currentLevel >= maxLevel;
              
              return (
                <div 
                  key={upgrade.id} 
                  className={`upgrade-item ${!isUnlocked ? 'locked' : ''} ${isOwned ? 'owned' : ''}`}
                >
                  <div className="upgrade-icon">{upgrade.icon}</div>
                  <div className="upgrade-details">
                    <h3>{upgrade.name}</h3>
                    <p className="upgrade-description">{upgrade.description}</p>
                    <div className="upgrade-stats">
                      <span>Effect: {upgrade.effect}</span>
                      {upgrade.maxLevel > 1 && (
                        <span>Level: {currentLevel}/{maxLevel}</span>
                      )}
                    </div>
                    {!isUnlocked && (
                      <p className="unlock-requirement">
                        🔒 Requires Level {upgrade.levelRequired}
                      </p>
                    )}
                  </div>
                  <div className="upgrade-actions">
                    <div className="upgrade-cost">${upgrade.cost}</div>
                    {isUnlocked && !isMaxLevel && (
                      <button 
                        onClick={() => handleBuyUpgrade(upgrade)}
                        disabled={money < upgrade.cost}
                        className="upgrade-btn"
                      >
                        {isOwned ? 'Upgrade' : 'Buy'}
                      </button>
                    )}
                    {isMaxLevel && (
                      <div className="max-level">MAX</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
