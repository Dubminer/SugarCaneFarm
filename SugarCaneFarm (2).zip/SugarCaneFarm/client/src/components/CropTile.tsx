import { FarmTile } from "../lib/stores/useFarmGame";

interface CropTileProps {
  tile: FarmTile;
  onClick: () => void;
  canPlant: boolean;
  canHarvest: boolean;
}

export default function CropTile({ tile, onClick, canPlant, canHarvest }: CropTileProps) {
  const getCropDisplay = () => {
    if (!tile.crop) return "";
    
    const { growthStage, maxGrowthStage, type } = tile.crop;
    const growthPercent = (growthStage / maxGrowthStage) * 100;
    
    // Different growth stages
    if (growthPercent < 25) return "🌱"; // Seedling
    if (growthPercent < 50) return "🌿"; // Young plant
    if (growthPercent < 75) return "🎋"; // Growing cane
    if (growthPercent < 100) return "🎍"; // Almost mature
    return "🌾"; // Ready to harvest
  };

  const getTileClass = () => {
    let className = "crop-tile";
    if (canPlant) className += " can-plant";
    if (canHarvest) className += " can-harvest";
    if (tile.crop && tile.crop.growthStage < tile.crop.maxGrowthStage) {
      className += " growing";
    }
    return className;
  };

  const getTooltipText = () => {
    if (!tile.crop) {
      if (canPlant) {
        return "Click to plant";
      } else {
        return "Not enough money or water";
      }
    }
    
    const { growthStage, maxGrowthStage, type, timeToGrow } = tile.crop;
    if (growthStage >= maxGrowthStage) {
      return `Ready to harvest ${type.name}! Value: $${type.baseValue}`;
    }
    
    const timeLeft = timeToGrow - (Date.now() - tile.crop.plantedAt);
    const minutesLeft = Math.ceil(timeLeft / (1000 * 60));
    return `${type.name} growing... ${minutesLeft}min left`;
  };

  return (
    <div 
      className={getTileClass()}
      onClick={onClick}
      title={getTooltipText()}
    >
      <div className="tile-content">
        {getCropDisplay()}
        {tile.crop && tile.crop.growthStage < tile.crop.maxGrowthStage && (
          <div className="growth-bar">
            <div 
              className="growth-progress"
              style={{ 
                width: `${(tile.crop.growthStage / tile.crop.maxGrowthStage) * 100}%` 
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
}
