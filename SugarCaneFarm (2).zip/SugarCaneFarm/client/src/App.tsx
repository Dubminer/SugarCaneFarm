import { useEffect } from "react";
import { useFarmGame } from "./lib/stores/useFarmGame";
import FarmGrid from "./components/FarmGrid";
import GameUI from "./components/GameUI";
import Shop from "./components/Shop";
import Upgrades from "./components/Upgrades";
import "./styles/farm-game.css";

function App() {
  const { loadGame, gameLoop, isShopOpen, isUpgradesOpen } = useFarmGame();

  // Load saved game on startup
  useEffect(() => {
    loadGame();
  }, [loadGame]);

  // Start game loop
  useEffect(() => {
    const interval = setInterval(() => {
      gameLoop();
    }, 1000); // Update every second

    return () => clearInterval(interval);
  }, [gameLoop]);

  return (
    <div className="farm-game">
      <div className="game-container">
        <GameUI />
        <FarmGrid />
        
        {isShopOpen && <Shop />}
        {isUpgradesOpen && <Upgrades />}
      </div>
    </div>
  );
}

export default App;
