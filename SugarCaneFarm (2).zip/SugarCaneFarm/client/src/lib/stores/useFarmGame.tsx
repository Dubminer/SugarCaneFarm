import { create } from "zustand";
import { sugarCaneTypes, upgrades } from "../gameData";

export interface SugarCaneType {
  id: string;
  name: string;
  description: string;
  cost: number;
  baseValue: number;
  growthTime: number; // in milliseconds
  experience: number;
  levelRequired: number;
  waterRequired: number;
}

export interface Crop {
  type: SugarCaneType;
  plantedAt: number;
  growthStage: number;
  maxGrowthStage: number;
  timeToGrow: number;
}

export interface FarmTile {
  crop: Crop | null;
}

export interface GameState {
  money: number;
  experience: number;
  level: number;
  farmGrid: FarmTile[][];
  selectedSeed: SugarCaneType | null;
  inventory: Record<string, number>;
  playerUpgrades: Record<string, number>;
  water: number;
  isShopOpen: boolean;
  isUpgradesOpen: boolean;
  
  // Actions
  plantCrop: (row: number, col: number, seedType: SugarCaneType) => void;
  harvestCrop: (row: number, col: number) => void;
  setSelectedSeed: (seed: SugarCaneType | null) => void;
  buySeeds: (seedType: SugarCaneType, quantity: number) => void;
  buyUpgrade: (upgrade: any) => void;
  buyWater: (quantity: number) => void;
  toggleShop: () => void;
  toggleUpgrades: () => void;
  gameLoop: () => void;
  saveGame: () => void;
  loadGame: () => void;
  resetGame: () => void;
  addMoney: (amount: number) => void;
  addExperience: (amount: number) => void;
}

const GRID_SIZE = 6;
const SAVE_KEY = "sugar-cane-farm-save";

const createEmptyGrid = (): FarmTile[][] => {
  return Array(GRID_SIZE).fill(null).map(() =>
    Array(GRID_SIZE).fill(null).map(() => ({ crop: null }))
  );
};

// Progressive XP system - each level requires more XP
const getXpRequiredForLevel = (level: number): number => {
  return 100 + (level - 1) * 50; // Level 1: 100, Level 2: 150, Level 3: 200, etc.
};

// Get total XP required to reach a specific level
const getTotalXpForLevel = (targetLevel: number): number => {
  let totalXp = 0;
  for (let i = 1; i < targetLevel; i++) {
    totalXp += getXpRequiredForLevel(i);
  }
  return totalXp;
};

export const useFarmGame = create<GameState>((set, get) => ({
  money: 100,
  experience: 0,
  level: 1,
  farmGrid: createEmptyGrid(),
  selectedSeed: sugarCaneTypes[0],
  inventory: {},
  playerUpgrades: {},
  water: 20,
  isShopOpen: false,
  isUpgradesOpen: false,

  plantCrop: (row: number, col: number, seedType: SugarCaneType) => {
    const state = get();
    const hasAutoIrrigation = state.playerUpgrades.autoIrrigation > 0;
    const waterTankLevel = state.playerUpgrades.waterTank || 0;
    const waterCostReduction = waterTankLevel * 0.25 + (hasAutoIrrigation ? 0.5 : 0);
    const waterCost = Math.max(1, Math.ceil(seedType.waterRequired * (1 - waterCostReduction)));

    if (state.money < seedType.cost) return;
    if (!hasAutoIrrigation && state.water < waterCost) return;

    const newGrid = [...state.farmGrid];
    const growthMultiplier = 1 + (state.playerUpgrades.fastGrowth || 0) * 0.2;
    const timeToGrow = seedType.growthTime / growthMultiplier;

    newGrid[row][col] = {
      crop: {
        type: seedType,
        plantedAt: Date.now(),
        growthStage: 0,
        maxGrowthStage: 4,
        timeToGrow: timeToGrow,
      }
    };

    set({
      farmGrid: newGrid,
      money: state.money - seedType.cost,
      water: hasAutoIrrigation ? state.water : state.water - waterCost,
    });
  },

  harvestCrop: (row: number, col: number) => {
    const state = get();
    const tile = state.farmGrid[row][col];
    if (!tile.crop || tile.crop.growthStage < tile.crop.maxGrowthStage) return;

    const valueMultiplier = 1 + (state.playerUpgrades.betterYield || 0) * 0.3;
    const xpMultiplier = 1 + (state.playerUpgrades.moreXp || 0) * 0.25;
    
    const harvestValue = Math.floor(tile.crop.type.baseValue * valueMultiplier);
    const harvestXp = Math.floor(tile.crop.type.experience * xpMultiplier);

    const newGrid = [...state.farmGrid];
    newGrid[row][col] = { crop: null };

    set({
      farmGrid: newGrid,
      money: state.money + harvestValue,
      experience: state.experience + harvestXp,
    });

    // Check for level up with progressive XP requirements
    const newState = get();
    let tempLevel = 1;
    let totalXpRequired = 0;
    
    while (totalXpRequired <= newState.experience) {
      totalXpRequired += getXpRequiredForLevel(tempLevel);
      if (totalXpRequired <= newState.experience) {
        tempLevel++;
      }
    }
    
    if (tempLevel > state.level) {
      set({ level: tempLevel });
    }
  },

  setSelectedSeed: (seed: SugarCaneType | null) => {
    set({ selectedSeed: seed });
  },

  buySeeds: (seedType: SugarCaneType, quantity: number) => {
    const state = get();
    const totalCost = seedType.cost * quantity;
    if (state.money >= totalCost) {
      set({ money: state.money - totalCost });
    }
  },

  buyUpgrade: (upgrade: any) => {
    const state = get();
    if (state.money >= upgrade.cost && state.level >= upgrade.levelRequired) {
      const newUpgrades = { ...state.playerUpgrades };
      newUpgrades[upgrade.id] = (newUpgrades[upgrade.id] || 0) + 1;
      
      set({
        money: state.money - upgrade.cost,
        playerUpgrades: newUpgrades,
      });
    }
  },

  buyWater: (quantity: number) => {
    const state = get();
    const cost = quantity * 2; // Water costs $2 per unit
    if (state.money >= cost) {
      set({
        money: state.money - cost,
        water: state.water + quantity,
      });
    }
  },

  toggleShop: () => {
    set(state => ({ 
      isShopOpen: !state.isShopOpen,
      isUpgradesOpen: false 
    }));
  },

  toggleUpgrades: () => {
    set(state => ({ 
      isUpgradesOpen: !state.isUpgradesOpen,
      isShopOpen: false 
    }));
  },

  gameLoop: () => {
    const state = get();
    const now = Date.now();
    let hasChanges = false;

    const newGrid = state.farmGrid.map(row =>
      row.map(tile => {
        if (!tile.crop) return tile;

        const timeSincePlanted = now - tile.crop.plantedAt;
        const growthProgress = timeSincePlanted / tile.crop.timeToGrow;
        const newGrowthStage = Math.min(
          Math.floor(growthProgress * tile.crop.maxGrowthStage),
          tile.crop.maxGrowthStage
        );

        if (newGrowthStage !== tile.crop.growthStage) {
          hasChanges = true;
          return {
            ...tile,
            crop: {
              ...tile.crop,
              growthStage: newGrowthStage,
            }
          };
        }

        return tile;
      })
    );

    if (hasChanges) {
      set({ farmGrid: newGrid });
    }
  },

  saveGame: () => {
    const state = get();
    const saveData = {
      money: state.money,
      experience: state.experience,
      level: state.level,
      farmGrid: state.farmGrid,
      inventory: state.inventory,
      playerUpgrades: state.playerUpgrades,
      water: state.water,
    };
    localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
  },

  loadGame: () => {
    const savedData = localStorage.getItem(SAVE_KEY);
    if (savedData) {
      try {
        const data = JSON.parse(savedData);
        set({
          money: data.money || 100,
          experience: data.experience || 0,
          level: data.level || 1,
          farmGrid: data.farmGrid || createEmptyGrid(),
          inventory: data.inventory || {},
          playerUpgrades: data.playerUpgrades || {},
          water: data.water || 20,
        });
      } catch (error) {
        console.error("Failed to load game:", error);
      }
    }
  },

  resetGame: () => {
    if (confirm("Are you sure you want to reset your farm? This cannot be undone!")) {
      localStorage.removeItem(SAVE_KEY);
      set({
        money: 100,
        experience: 0,
        level: 1,
        farmGrid: createEmptyGrid(),
        inventory: {},
        playerUpgrades: {},
        water: 20,
        isShopOpen: false,
        isUpgradesOpen: false,
        selectedSeed: sugarCaneTypes[0],
      });
    }
  },

  addMoney: (amount: number) => {
    set(state => ({ money: state.money + amount }));
  },

  addExperience: (amount: number) => {
    const state = get();
    const newXp = state.experience + amount;
    
    let currentLevel = state.level;
    let remainingXp = newXp;
    
    // Calculate level based on total XP
    let tempLevel = 1;
    let requiredXp = 0;
    
    while (requiredXp <= newXp) {
      requiredXp += getXpRequiredForLevel(tempLevel);
      if (requiredXp <= newXp) {
        tempLevel++;
      }
    }
    
    set({
      experience: newXp,
      level: Math.max(state.level, tempLevel),
    });
  },
}));
